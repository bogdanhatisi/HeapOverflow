export interface UserData {
  displayName: string;
  emailAddress: string;
  password: string;
  aboutMe?: string;
  location?: string;
}
