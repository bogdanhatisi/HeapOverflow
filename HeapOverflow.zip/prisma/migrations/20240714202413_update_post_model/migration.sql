-- AlterTable
ALTER TABLE "Post" ALTER COLUMN "parent_question_id" DROP DEFAULT;
